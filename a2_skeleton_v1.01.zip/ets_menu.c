/***********************************************************************
 * COSC1076 - Advanced Programming Techniques
 * Summer 2015 Assignment #2
 * Full Name        : EDIT HERE
 * Student Number   : EDIT HERE
 * Course Code      : EDIT HERE
 * Program Code     : EDIT HERE
 * Start up code provided by David Shaw
 * Based on 2014 code by Paul Miller and Virginia King
 **********************************************************************/
#include "ets_menu.h"

/* initialises the menu */
void menu_init(struct menu_item * menu)
{
  /* The UNUSED() function is designed to prevent warnings while your 
     * code is only partially complete. Delete this function call once 
     * you are using your own code */
    UNUSED(menu);
}
